class Bahn {
    construcor() {

    }

    static init() {
        document.querySelector('#bahnFrame').onload = function() {
            setInterval(function() {
                Bahn.update();
            }, 5000);
        }.bind(this);

    }

    static update() {
    	var cr = 0;
        try {
            //alert(document.querySelector("#bahnFrame").contentWindow.window.document.querySelector("tbody").innerHTML);
            document.querySelector("#bahn").innerHTML = ("<table><th>Abfahrt</th><th>Ziel</th>") + document.querySelector("#bahnFrame").contentWindow.window.document.querySelector("tbody").innerHTML + "</table>"
            //search for tripMessage with not &nbsp;
            cr++;
            var tr = document.querySelector("#bahn").querySelectorAll("tr");
            cr++;
            for (var i = 0; i < tr.length; i++) {
            	tr[i].innerHTML;
                var msg = tr[i].querySelector(".tripMessage").innerHTML;
                cr++;
                if (msg != "&nbsp;" && msg != "") {
                    alert(msg);
                    tr[i].querySelectorAll("td")[1].innerHTML += "<br>" + msg;
                }
            }

        } catch (e) {
            Popup.open(cr+":<br>"+e);
        }
    }
}